$ErrorActionPreference = "SilentlyContinue"
$schemeName = "Roblox 2013 Cursor"
$curDir = "$env:LOCALAPPDATA\CursorsU\$schemeName"
New-Item -ItemType Directory -Force -Path $curDir | Out-Null

$arrowFile = "Roblox 2013 Cursor--cursor--SweezyCursors.cur"
$handFile = "Roblox 2013 Cursor--pointer--SweezyCursors.cur"

if (Test-Path $arrowFile) { Copy-Item $arrowFile -Destination "$curDir\$arrowFile" -Force }
if (Test-Path $handFile) { Copy-Item $handFile -Destination "$curDir\$handFile" -Force }

$regPath = "HKCU:\Control Panel\Cursors"
if (Test-Path "$curDir\$arrowFile") {
    Set-ItemProperty -Path $regPath -Name "Arrow" -Value "$curDir\$arrowFile"
    Set-ItemProperty -Path $regPath -Name "(Default)" -Value $schemeName
}
if (Test-Path "$curDir\$handFile") {
    Set-ItemProperty -Path $regPath -Name "Hand" -Value "$curDir\$handFile"
}

$code = @"
using System;
using System.Runtime.InteropServices;
public class Win32Cursor {
    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool SystemParametersInfo(uint uiAction, uint uiParam, IntPtr pvParam, uint fWinIni);
}
"@
Add-Type -TypeDefinition $code
[Win32Cursor]::SystemParametersInfo(0x0057, 0, [IntPtr]::Zero, 3)
