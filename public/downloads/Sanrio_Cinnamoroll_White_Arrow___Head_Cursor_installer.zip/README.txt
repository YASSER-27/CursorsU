CURSORS U - Sanrio Cinnamoroll White Arrow & Head Cursor
Author: Yasser-27 (https://github.com/YASSER-27)

INSTALLATION INSTRUCTIONS:

Method 1 (Instant 1-Click - Recommended):
  Double-click 'Install_OneClick.bat' to immediately activate this cursor on your PC!

Method 2 (Standard Windows INF):
  Right-click 'Install.inf' and choose 'Install'.
  Open Windows Settings -> Mouse -> Pointers and select 'Sanrio Cinnamoroll White Arrow & Head Cursor'.

TO RESTORE DEFAULT CURSOR:
  Double-click 'Uninstall_RestoreDefault.bat'.
