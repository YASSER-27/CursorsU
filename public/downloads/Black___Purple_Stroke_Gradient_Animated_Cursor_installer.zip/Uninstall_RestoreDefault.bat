@echo off
reg delete "HKCU\Control Panel\Cursors" /v Arrow /f
reg delete "HKCU\Control Panel\Cursors" /v Hand /f
powershell -Command "Add-Type 'using System.Runtime.InteropServices; public class W { [DllImport(\"user32.dll\")] public static extern bool SystemParametersInfo(uint a, uint b, System.IntPtr c, uint d); }'; [W]::SystemParametersInfo(0x0057, 0, [System.IntPtr]::Zero, 3)"
echo Default Windows cursor restored!
pause
