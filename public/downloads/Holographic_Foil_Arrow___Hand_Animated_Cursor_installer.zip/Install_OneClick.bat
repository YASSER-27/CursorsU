@echo off
setlocal
cd /d "%~dp0"
echo =======================================================
echo Installing Holographic Foil Arrow & Hand for Windows Mouse...
echo =======================================================
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
echo.
echo Cursor applied successfully to your Windows PC!
pause
